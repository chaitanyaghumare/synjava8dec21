interface Connection {
	public void open();

	public default void close() {
		System.out.println("Connection - default close ");
	}
}

interface Transaction {
	public void start();
	// public void close();

	public default void close() {
		System.out.println("Transaction - default close ");
	}

}

class Impl1 implements Connection, Transaction {

	@Override
	public void start() {
		System.out.println("start from Impl1");
	}

	@Override
	public void open() {
		System.out.println("open from Impl1");
	}
	
	 @Override public void close() { System.out.println("Close from Impl1"); } }
	

public class Lab1 {
	public static void main(String[] args) {
		Connection con = new Impl1();
		con.open();
		con.close();
		Transaction tran = new Impl1();
		tran.start();
		tran.close();
		
		
	}
}
