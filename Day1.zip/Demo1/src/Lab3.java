interface Lab3Interface{
	public void m1();
	public default void m2() {
		System.out.println("in default method of m2 in Lab3Interface");
	}
}
class Lab3Impl implements Lab3Interface{

	@Override
	public void m1() {
		System.out.println("Lab3Impl - m1 method");
	}
	@Override
	public void m2() {
		// TODO Auto-generated method stub
		System.out.println("Lab3Impl - m2 overriden");
	}
}
public class Lab3 {
public static void main(String[] args) {
	/*
	 * Lab3Interface demo = new Lab3Impl(); demo.m1(); demo.m2();
	 */
	
	Lab3Interface impl = ()->System.out.println("Lab3 - lambda... ");
	impl.m1();
	impl.m2();
}
}
