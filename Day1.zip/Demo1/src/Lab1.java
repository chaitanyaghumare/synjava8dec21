import java.util.Date;
public class Lab1 {
	public static void main(String[] args) {
		Runnable helper = () -> System.out.println("in run method of Lab1Helper");
		Thread t1 = new Thread(helper);
		t1.start();
	}
}
