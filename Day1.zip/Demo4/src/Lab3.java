import java.util.ArrayList;
import java.util.List;

/*
Write Lab3.java
		
Delete all employees where salary > 3000
	removeIf
	
Delete all employees where name is ""

*/
@FunctionalInterface
interface CheckEmp {
	public boolean test(Emp s);
}

class ProcessEmp {
	private List<Emp> list = new ArrayList<>();

	public List<Emp> getList(){
		return list;
	}
	public ProcessEmp() {
		for (int i = 1; i <= 100; i++) {
			list.add(new Emp(i, "aaa" + i, i * 100));
		}
	}
	public int count(CheckEmp chk) {
		int cnt = 0;
		for (Emp emp : list) {
			if (chk.test(emp))
				cnt++;
		}
		return cnt;
	}

}

public class Lab3 {
public static void main(String[] args) {
	ProcessEmp emps = new ProcessEmp();
	System.out.println("Count Employees where salary < 1500 :  " + emps.count((e)-> e.getSalary() <1500)) ;
	System.out.println("Count Employees where ename starts 'aaa2' salary < 5000 :  " + emps.count((e)-> e.getSalary() <5000 && e.getEname().startsWith("aaa2"))) ;
	for (Emp emp :emps.getList()) {
		System.out.println(emp);
	}
	System.out.println("Count before delete : " + emps.getList().size());
	emps.getList().removeIf(e->e.getSalary()>3000);
	System.out.println("Count after delete : " + emps.getList().size());



	
}
}