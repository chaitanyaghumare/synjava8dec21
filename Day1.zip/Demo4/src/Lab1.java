@FunctionalInterface
interface Calc1 {
	public int sqr(int input);
}

@FunctionalInterface
interface Calc2 {
	public int add(int input1, int input2);
}

@FunctionalInterface
interface Calc3 {
	public int len(String str);
}

@FunctionalInterface
interface Calc4 {
	public boolean checkeven(int num);
}

public class Lab1 {
	public static void main(String[] args) {
      Calc1 calc1=(n)->n*n;
      Calc2 calc2=(n1,n2)-> n1+n2;
      Calc3 calc3=(str)->str.length();
      Calc4 calc4 = (n)-> n%2==0;
      System.out.println(calc1.sqr(2));
      System.out.println(calc2.add(5, 2));
      System.out.println(calc3.len("abcd"));
      System.out.println(calc4.checkeven(2));
	}
}
