interface Lab4Interface {
	public void m1();
    public static void m2() {
		System.out.println("Lab4Interface - m2 - static ");
	}
}
class Lab4Impl implements Lab4Interface {
	@Override
	public void m1() {
		System.out.println("m1 in Lab4Impl");
	}
}

public class Lab4 {
	public static void main(String[] args) {
	Lab4Interface int1 = new Lab4Impl();
	int1.m1();
	Lab4Interface.m2();
}
}
