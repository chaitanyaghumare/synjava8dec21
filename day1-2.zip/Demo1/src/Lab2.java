@FunctionalInterface
interface Lab2Interface {
	public void m1();
//	public void m2();
}

public class Lab2 {
public static void main(String[] args) {
	Lab2Interface d1 = ()->System.out.println("in Lab2Impl in main method using lambda");
	d1.m1();
}
}
