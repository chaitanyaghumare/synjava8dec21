package opt;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
public class EmpManager {
	private List<Emp> list = new ArrayList<Emp>();
	public void insert(Emp d) {
		list.add(d);
	}
	public List<Emp> getList() {
		return list;
	}
	public Optional<Emp> getEmp(int empno) {
		for (Emp emp : list) {
			if (emp.getEmpno() == empno)
				return Optional.of(emp);
		}
		return Optional.empty();
	}
	public static void main(String[] args) {
		EmpManager mgr = new EmpManager();
		for (int i = 1; i < 10; i += 1) {
			Emp d = new Emp();
			d.setEmpno(i); 		d.setEname("enameof" + i); 			d.setSalary(i * 100);
			mgr.insert(d);
		}
		Optional<Emp> e = mgr.getEmp(5);
		if (e.isPresent())
		
		e.ifPresent((emp)->System.out.println("getEmp of  5" + emp.getEname()));
		e = mgr.getEmp(55);
		if (e.isPresent())
			System.out.println("getEmp of  55" + e.get().getEname());
		else
			System.out.println("Employee 55 does not exist");

	}
}
