import java.util.Date;

public class Lab1 {
public static void main(String[] args) {
	System.out.println("Util Date =" + new Date());
	System.out.println("SQL Date = " + new java.sql.Date(System.currentTimeMillis()));
}
}
// javac -profile compact1 Lab1.java
