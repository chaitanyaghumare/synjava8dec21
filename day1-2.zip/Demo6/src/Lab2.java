import java.time.LocalDate;
import java.util.Scanner;

public class Lab2 {
public static void main(String[] args) {
	LocalDate d1 = LocalDate.of(2021, 12,2);
	System.out.println(d1);
// accept (scanner) date, month and year and create date and print
	System.out.println("Please enter year, month and day to generate the localdate");
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter Year : ");
	int year = sc.nextInt();
	System.out.println("Enter Month : ");
	int month = sc.nextInt();
	System.out.println("Enter Day : ");
	int day = sc.nextInt();
	LocalDate lDate = LocalDate.of(year, month, day);
	System.out.println("Created local date - "+lDate);

}
}
