import java.io.FileReader;
import java.net.URL;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

public class Lab4 {
    public static void main(String[] args) throws Exception {
        ScriptEngineManager factory = new ScriptEngineManager();
        ScriptEngine engine = factory.getEngineByName("nashorn");
        try {
          //  engine.eval("print('Hello, World!');");
        	URL url = Lab4.class.getResource("hello.js");
        	engine.eval(new FileReader(url.getFile()));
        } catch (final Exception se) { se.printStackTrace(); }
    }
}
// create hello.js , load the file and execute