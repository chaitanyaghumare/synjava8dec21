import java.lang.annotation.Annotation;

public class Lab4 {
public static void main(String[] args) {
	Class aClass = Lab1.class;
	Annotation[] annotations = aClass.getAnnotations();

	for(Annotation annotation : Lab2.class.getAnnotations()){
		System.out.println(annotation.annotationType());
		if (annotation instanceof Writer) {
			Writer w =(Writer) annotation;
			System.out.println(w.name() + " , " + w.datetime());
					
		}
		System.out.println("-----------------------------");
		   Writer[] writers = Lab1.class.getAnnotationsByType(Writer.class);  
	        for (Writer w  : writers) {    // Iterating values  
	            System.out.println(w.name()+" on "+w.datetime());  
	        }  
	        
		/*
		 * if(annotation instanceof MyAnnotation){ MyAnnotation myAnnotation =
		 * (MyAnnotation) annotation; System.out.println("name: " +
		 * myAnnotation.name()); System.out.println("value: " + myAnnotation.value()); }
		 */
	}
}
}
