
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
@Repeatable(Writers.class)
@Retention(RetentionPolicy.RUNTIME)
 @interface Writer {	
			String   name();
			String   datetime();
	}
@Retention(RetentionPolicy.RUNTIME)
@interface Writers{
	Writer[] value();
}
