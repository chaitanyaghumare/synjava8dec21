import java.util.Arrays;
import java.util.List;

interface Process{
	public int sum(List<Integer> l1);
}
public class Lab2 {
public static void main(String[] args) {
	Process p1 = (list)->{
		int sum = 0;
		for (Integer num : list) {
			sum += num;
		}
		return sum;
	};
	
	System.out.println("Sum = " + 
			p1.sum(Arrays.asList(new Integer[]{10,30,50,20,40})));
}
}
