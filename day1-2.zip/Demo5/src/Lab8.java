import java.util.Arrays;
import java.util.List;
import java.util.function.BiFunction;
import java.util.function.BiPredicate;
import java.util.function.BinaryOperator;
import java.util.function.Function;
import java.util.function.UnaryOperator;

public class Lab8 {
public static void main(String[] args) {
	Function<String, Integer> strlen = (str)->str.length();
	System.out.println("Length of 'Vaishali' : " + strlen.apply("vaishali"));

	Function<List<Integer>, Integer> sumoflist = (list)->{int sum = 0;
		for (Integer num : list) {
			sum+=num;
		}
		return sum;
	};
	System.out.println("Sum of List = " + sumoflist.apply(Arrays.asList(new Integer[]{10,30,50,20,40})));
	
	
	Function<Integer, Integer> sqr = (num) -> num * num;
	UnaryOperator<Integer> sqr1 = (num)->num*num;
	System.out.println("Square of 10" + sqr.apply(10));
	System.out.println("Square of 10" + sqr1.apply(10));
	BiFunction<Integer, Integer, Integer> add = (num1, num2) -> num1+num2;
	BinaryOperator<Integer> add1 =  (num1, num2) -> num1+num2;
	System.out.println("addition of 10,10 =" + add.apply(10, 10));
	System.out.println("addition of 10,10 =" + add1.apply(10, 10));

	
	
	
}
}
