import java.util.function.IntPredicate;
import java.util.function.Predicate;

public class Lab5 {
public static void main(String[] args) {
	/*
	@FunctionalInterface
	interface Calc4 {
		public boolean test(int num);
	}
	Calc4 var1 = (num)->num%2==0;
	*/
	//Predicate<Integer> var1  = (num1)->num1%2==0;
	IntPredicate var1  = (num1)->num1%2==0;
	System.out.println("Check Even for 10 " + var1.test(10));
	System.out.println("Check Even for 11 " + var1.test(11));
//----------------------------------------------------------
/*	@FunctionalInterface
	interface CheckEmp {
		public boolean test(Emp s);
	}
	CheckEmp chkemp = (e)->e.getEmpno()==10;
*/
	Predicate<Emp> chkemp =  (e)->e.getEmpno()==10;
	Emp e1  = new Emp(10,"aaa",111.11);
	System.out.println("Check Employee for empno 10 : "  + chkemp.test(e1));
	 e1  = new Emp(11,"aaa",111.11);
	System.out.println("Check Employee for empno 10 : "  + chkemp.test(e1));





}
}
