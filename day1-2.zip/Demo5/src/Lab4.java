import java.util.Arrays;
import java.util.List;

public class Lab4 {
public static void main(String[] args) {
	List<Integer> l1 = Arrays.asList(new Integer[]{10,30,50,20,40});
System.out.println("-----------Option 1 ----------------");
	for (Integer no : l1) {
		System.out.println(no);
	}
	System.out.println("-----------Option 2 ----------------");
	l1.forEach((no)->System.out.println(no));
	
	System.out.println("-----------Option 3 ----------------");
	l1.forEach(System.out::println);
	
}
}
