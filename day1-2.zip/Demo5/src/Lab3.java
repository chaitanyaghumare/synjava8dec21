interface Bank{
	public int calcInterest(int amount, int months);
}
public class Lab3 {
public static void main(String[] args) {
	int  rate = 8;
	// effectively final
//	rate = 200;
	Bank b1 = (amt, months)->{
//		rate = 10;
		System.out.println("current rate is " + rate);
		return (amt*months*rate)/1200;
	};
	//rate = 10;
	System.out.println("Interest = " + b1.calcInterest(1000, 12) );
}
}
