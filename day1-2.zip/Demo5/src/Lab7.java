import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class Lab7 {
public static void main(String[] args) {
	Consumer<String> prn = (str)->System.out.println(str);
	prn.accept("aaa");
	List<String> list = new ArrayList<String>();
	list.add("aaa"); list.add("bbb");
	System.out.println("in main before modify call : "+ list);
	// not functional
	Consumer<List<String>> modify = (list1)->{
			list1.add("ccc");
			System.out.println("in modify " + list1);
	};
	modify.accept(list);
	System.out.println("in Main : "+ list);
	
	
	Supplier<Integer> supplier = ()->(int)(Math.random()*1000);
	System.out.println("Supplier " + supplier.get());
}
}
