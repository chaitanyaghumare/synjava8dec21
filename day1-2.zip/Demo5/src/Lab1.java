interface Calc1{
	public int sqr(int i);
}
interface Calc2{
	public int generate();
}
public class Lab1 {
public static void main(String[] args) {
	// simple syntax (data type inferred)
	Calc1 m1 = (i)->i*i;
	System.out.println("SQR of 10 :" + m1.sqr(10));
	// with data type 
	m1 = (int i)->i*i;
	System.out.println("SQR of 15 :" + m1.sqr(15));
	// empty parentheses if no parameter
	Calc2 m2 =  () -> (int)(Math.random()*1000);
	System.out.println("No input parameter : " + m2.generate());
	// skip parentheses for simple parameter
	m1 = i->i*i;
	System.out.println("SQR of 20 :" + m1.sqr(20));
	// multiline code in curly braces and require return
	m1 = i->{
		System.out.println("in sqr with " + i);
		return i*i;};
	System.out.println("SQR of 25 :" + m1.sqr(25));
}
	
}
