import java.util.function.BiPredicate;
import java.util.function.IntPredicate;
import java.util.function.Predicate;

public class Lab6 {
	public static void main(String[] args) {

		// 1. pass String as an argument and check if not null
		Predicate<String> p1 = (str) -> str != null;
		System.out.println("String 'Good Morning' check predicate = " + p1.test("Good Morning"));
		System.out.println("String null check predicate = " + p1.test(null));

		// 2. pass integer as an argument and check greater than 1000
		//	Predicate<Integer> p2 = (num)->num>1000;
		IntPredicate p2 = (num) -> num > 1000;
		System.out.println("Integer greater than 1000 predicate with 1001 = " + p2.test(1001));
		System.out.println("Integer greater than 999 predicate with 999 = " + p2.test(999));

		// 3. check the input parameter type - return true if it is String else return false
		Predicate<Object> p3 = o -> o instanceof String;
		System.out.println("Check with 'test'  : " + p3.test("test1"));
		System.out.println("Check with 999  :  " + p3.test(999));

		// 4. pass two int arguments return true if first argument is bigger than second

		BiPredicate<Integer, Integer> p4 = (n1, n2) -> n1 > n2;
		System.out.println("First param Greater in 12,10  values predicate = " + p4.test(12, 10));
		System.out.println("First param Greater in 10,20 values predicate = " + p4.test(10, 20));

		// 5. pass two string arguments and return true is equal else false
		BiPredicate<String, String> p5 = (s1, s2) -> s1.equals(s2);
		System.out.println("Strings are equal or not predicate with 'abc' and 'abc' = " + p5.test("abc", "abc"));
		System.out.println("Strings are equal or not predicate with 'xyz' and 'abc' = " + p5.test("xyz", "abc"));
	}

}
